#!/bin/bash

proot-distro login debian --user user --termux-home -- sh run4.sh