#!bin/bash

apt update && apt full-upgrade -y

termux-setup-storage

termux-change-repo

pkg i x11-repo  -y

pkg i root-repo

pkg i virglrenderer-android -y

pkg i termux-x11-nightly -y

pkg i proot-distro -y

pkg i bash-completion

pkg i termux-api

pkg i pulseaudio -y

pkg i neovim -y

pkg i cmake -y

pkg i nodejs -y

pkg i neofetch -y

pkg i cowsay -y

pkg i gradle -y

pkg i fish -y

pkg i clang -y

pkg i openjdk-17-jdk

pkg i curl -y

pkg i hollywood -y

pkg install git -y

git clone https://github.com/termux/termux-x11

cd termux-x11

git submodule update --init --recursive

cd

apt install wget -y

apt update && apt upgrade -y

cd ~/.termux

nvim termux.properties

termux-reload-settings

cd

pkg install proot-distro

proot-distro install debian

apt update && apt dist-upgrade -y

proot-distro login debian --user root --termux-home -- sh run2.sh

sleep 2

cowsay "Logging as user to setup proot desktop env, this will take quite some time and around 6gb of sorage!"

sh run3.sh
