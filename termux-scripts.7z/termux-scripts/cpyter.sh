#!/bin/bash

cp -t ~/ ~/storage/downloads/termux/run1.sh ~/storage/downloads/termux/run2.sh ~/storage/downloads/termux/run3.sh ~/storage/downloads/termux/run4.sh

chmod +x run1.sh run2.sh run3.sh run4.sh