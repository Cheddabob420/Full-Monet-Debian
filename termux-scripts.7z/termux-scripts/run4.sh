#!/bin/bash

sudo apt install neofetch fish gradle clang cmake cowsay wget nodejs curl xfce4 xfce4-goodies dbus-x11 openjdk-17-jdk -y

update-alternatives && config x-terminal-emulator

bash -c  "$(curl -fsSL https://raw.githubusercontent.com/officialrajdeepsingh/nerd-fonts-installer/main/install.sh)"
sudo apt install xfce4-whiskermenu-plugin
sudo apt install mugshotapt 
apt search icon-theme
sudo apt install papirus-icon-theme moka-icon-theme
apt search gtk-themes
sudo apt install numix-gtk-theme
sudo apt install greybird-gtk-theme
sudo apt install plank
plank --preferences 
sudo apt install conky-all